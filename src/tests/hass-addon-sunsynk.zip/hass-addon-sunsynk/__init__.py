"""Add-on tests."""
